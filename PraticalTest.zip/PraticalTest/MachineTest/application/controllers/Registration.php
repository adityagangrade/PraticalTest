<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//session_start(); //we need to call PHP's session object to access it through CI

class Registration extends CI_Controller{
	public function __construct() {
        parent:: __construct();
        /*load user model*/
        $this->load->model('User');
        $this->load->library('session');

    }
	public function index(){
	 $this->load->view('register');
	}

	/*Addcandidate function start*/
	function addCandidate(){
            
    		$data = array(
                 'name' => $this->input->post('name'),
                 'phone' => $this->input->post('phone'),
                 'day' =>$this->input->post('day'),
                 'timeslot' =>$this->input->post('timeslot'),
                 'email'=>$this->input->post('email'),
                 'date'=>$this->input->post('date'),
                 'comments'=>$this->input->post('comments'),
                
            );

            /*call model function*/
            $insert =$this->User->register($data);
            if($insert){
                $this->session->set_flashdata('success', 'Data Add successfully');
            redirect('Registration/dashbord');

            }else{
                $this->session->set_flashdata('error', 'Data Not Add successfully');
            redirect('Registration');

            }
	}

	/*Addcandidate function end*/

        // getdate function
    function getdate(){
        $days = $this->input->post('capacityValue');
        $timeslot = $this->input->post('times');
        
            /*call model function details*/
        $data =$this->User->details($days,$timeslot);
        if($data){
            echo 1;
        }
    }

   
    // getdate function end

        /*dashbord function*/
    function dashbord(){
            /*call model login function*/            
            $data['userdata'] =$this->User->alluserDetail();
            if($data){
                $this->load->view('dashbord',$data);
            }
    }
    // dashbord function end

}

?>
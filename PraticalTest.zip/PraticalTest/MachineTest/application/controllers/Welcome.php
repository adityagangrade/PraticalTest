<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	 function my_mPDF(){

 


$filename = time()."_order.pdf";

 


$html = $this->load->view('mpdf');

 

// unpaid_voucher is unpaid_voucher.php file in view directory and $data variable has infor mation that you want to render on view.

 


$this->load->library('Mpdf');

 


$this->m_pdf->pdf->WriteHTML($html);

 

//download it D save F.

 


$this->m_pdf->pdf->Output("./uploads/".$filename, "F");

}

}
?>

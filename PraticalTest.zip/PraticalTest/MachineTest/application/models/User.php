<?php

class User extends CI_Model
{
	/*data insert in database*/
	public function register($data){
		$this->db->insert('candidate',$data);
		return true;
	}
	/*data insert in database end*/

	// get alluser data
	function alluserDetail(){
		$qury= $this->db->select('*')
		      ->from('candidate')
		 	->get();
		return $qury->result();
	}
	// get alluser data end

	// check function slot allready booked
	function details($days,$timeslot){
		$que=$this->db->query("select * from candidate where day='".$days."' and timeslot='".$timeslot."'");
			$row = $que->row();
			return $row;
	}

	
	// check function slot allready booked end

	
}
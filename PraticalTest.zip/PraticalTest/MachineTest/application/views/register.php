<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

</head>
<body>

<div class="container">
        <div class="row centered-form">
        	<div class="panel panel-default">
        		
			 			<?php if ($this->session->flashdata('success')) { ?>
							<h3> <?php echo $this->session->flashdata('success'); ?></h3>
						<?php } ?>
						<?php if ($this->session->flashdata('error')) { ?>
							<h3><?php echo $this->session->flashdata('error'); ?></h3>
						<?php } ?>
					<div class="panel-heading">
			    		<h3 class="panel-title">Booking Form</h3>
			 	</div>

			 			<div class="panel-body">
			    		<form role="form" action="<?php echo base_url('Registration/addCandidate')?>" method="post" >
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">

			    					<div class="form-group">
			               			 	<p>Name:<span style="color: red;">*</span></p>
			               			 	<input type="text" name="name" id="name" class="form-control input-sm" placeholder=" Name">
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			               			 	<p>Mobile Number:<span style="color: red;">*</span></p>

			    						<input type="text" name="phone" id="phone" class="form-control input-sm" placeholder="Mobile Number" minlength="10" maxlength="10">
			    					</div>
			    				</div>
			    				
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			               			 	<p>Email:<span style="color: red;">*</span></p>
			    					<input type="email" name="email" id="emails" class="form-control input-sm" placeholder="Email Address">

			    					</div>
			    				</div>

			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			               			 	<p>Day:<span style="color: red;">*</span></p>
			               			 	<select name="day" id="day" class="form-control input-sm days" >
			               			 		<option value="">select option</option>
			               			 		<option data-capacity="monday" value="monday">Monday</option>
			               			 		<option data-capacity="tuesday"  value="tuesday">Tuesday </option>
			               			 		<option data-capacity="wednesday" value="wednesday">Wednesday</option>
			               			 		<option data-capacity="thursday" value="thursday">Thursday </option>
			               			 		<option data-capacity="friday" value="friday">Friday</option>
			               			 		<option data-capacity="saturday" value="saturday ">Saturday  </option>
			               			 		<option data-capacity="sunday" value="sunday">Sunday</option>

			               			 	</select>
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			               			 	<p>Time Slot:<span style="color: red;">*</span></p>
			               			 	<select name="timeslot" id="timeslot" class="form-control input-sm" >
			               			 		<option value="">select option</option>
			               			 		<option  value="10:00-10:30">10:00-10:30</option>
			               			 		<option  value="10:30-11:00">10:30-11:00</option>
			               			 		<option  value="11:30-12:00"> 11:30-12:00</option>
			               			 		<option  value="12:00-12:30"> 12:00-12:30</option>
			               			 		<option  value="12:30-01:00"> 12:30-01:00</option>

			               			 	</select>
			    					</div>
			    				</div>

			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			               			 	<p>Date:<span style="color: red;">*</span></p>
			    					<input type="date" name="date" id="date" required class="form-control input-sm  getdate" placeholder="Email Address">

			    					</div>
			    				</div>
			    			<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			               			 	<p>Comments :<span style="color: red;">*</span></p>
			               			 	<textarea name="comments"  style="height: 100px; width: 400px;" id="comments"></textarea>
			    				
			    					</div>
			    				</div>
			  

			    				  
			    			</div>
			    			
			    			
			    			<input type="submit" value="Submit" id="btn-submit" class="btn btn-info btn-block">		    		
			    		</form>
			    	</div>
	    		</div>
    	
    	</div>
    </div>

</body>
</html>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
 $(document).ready(function() { 
 
    $('#btn-submit').click(function() {  
 
        $(".error").hide();
        var hasError = false;
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      var emailblockReg = /^([\w-\.]+@(?!yahoo.com)(?!hotmail.com)([\w-]+\.)+[\w-]{2,4})?$/;
		    intRegex = /[0-9 -()+]+$/;
		

        var name = $("#name").val();
		var phone  = $('#phone').val();
		var timeslot = $('#timeslot').val();
		var day = $('#day').val();
        var emailaddressVal = $("#emails").val();
		var	date = $("#date").val();
		var comments = $("#comments").val();	
  
		if(name == ''){
			     $("#name").after('<span class="error" style="color:red;">Please enter your name</span>');
            hasError = true;
		}

		if(phone == '' || (!intRegex.test(phone))){
			     $("#phone").after('<span class="error" style="color:red;">Please enter your phone no or valid phone no</span>');
            hasError = true;
		}
		if(timeslot == ''){
			     $("#timeslot").after('<span class="error" style="color:red;">Please select your timeslot </span>');
            hasError = true;
		}
		if(day == ''){
			     $("#day").after('<span class="error" style="color:red;">Please select day </span>');
            hasError = true;
		}
		if(date == ''){
			     $("#date").after('<span class="error" style="color:red;">Please select your date </span>');
            hasError = true;
		}
		if(comments == ''){
			$("#comments").after('<span class="error" style="color:red;">Please enter your comments </span>');
            hasError = true;
		}
        if(emailaddressVal == '') {
            $("#emails").after('<span class="error" style="color:red;">Please enter your email address.</span>');
            hasError = true;
        }
 
        else if(!emailReg.test(emailaddressVal)) {
            $("#emails").after('<span class="error" style="color:red;">Enter a valid email address.</span>');
            hasError = true;
        }
        
    else if(!emailblockReg.test(emailaddressVal)) {
      $("#emails").after('<span class="error" style="color:red;">Please only enter gmail address.</span>');
      hasError = true
    } 
        if(hasError == true) { return false; }
 
    });
});

</script>

<script type="text/javascript">
var dat ='';
var time ='';
$('#day').on('change', function() {
  var dat=this.value;

  filterFunction();
});

$('#timeslot').on('change', function() {
  var time=this.value;
  filterFunction(time);
});

function filterFunction(time){
		 var capacityValue = $('select.days').find(':selected').data('capacity');
		 var times	= time;

		 $.ajax({
            type:"POST",
            url:"<?= base_url('Registration/getdate'); ?>",
            data:{capacityValue:capacityValue,times:times},
            success:function(data){
                if(data == 1){
                    swal({
                     title: "Error!",
                     text: "This slot allready booked ",
                     icon: "error",
                     timer: 6000
                     });
                }
            }
        });

		
 }
 </script>

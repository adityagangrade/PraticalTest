<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
<div class="row">
	<div class="col-md-12">
	<div class="col-md-6"><p>Detail Dashbord</p></div>
	
	</div>
<div class="col-md-12">

            <?php if ($this->session->flashdata('success')) { ?>
              <h3> <?php echo $this->session->flashdata('success'); ?></h3>
            <?php } ?>
            <?php if ($this->session->flashdata('error')) { ?>
              <h3><?php echo $this->session->flashdata('error'); ?></h3>
            <?php } ?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Phone No</th>
      <th scope="col">Email</th>
           <th scope="col">Day</th>
      <th scope="col">Timeslot</th>
      <th scope="col">Date</th>
      <th scope="col">Comments</th>

    </tr>
  </thead>
  <tbody>
  	<?php foreach($userdata as $val){?>
    <tr>
      <th scope="row"><?= $val ->id?></th>
      <td><?= $val ->name?></td>
      <td><?= $val ->phone?></td>
      <td><?= $val ->email?></td>
      <td><?= $val ->day?></td>
      <td><?= $val ->timeslot?></td>
      <td><?= $val ->date?></td>
      <td><?= $val ->comments?></td>

    </tr>
    <?php }?>
  </tbody>
</table>
</div>
</body>
</html>